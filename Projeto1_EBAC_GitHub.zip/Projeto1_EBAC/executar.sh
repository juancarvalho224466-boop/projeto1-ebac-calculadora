#!/bin/bash
# Executa a calculadora em Python 3.
python3 calculator.py
