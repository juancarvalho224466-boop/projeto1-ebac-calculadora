def calculadora():
    print("=== Calculadora em Python ===")

    while True:
        try:
            numero1 = float(input("Digite o primeiro número: ").replace(",", "."))
            numero2 = float(input("Digite o segundo número: ").replace(",", "."))
        except ValueError:
            print("Entrada inválida. Digite apenas números.\n")
            continue

        print("\nEscolha uma operação:")
        print("1 - Adição (+)")
        print("2 - Subtração (-)")
        print("3 - Multiplicação (*)")
        print("4 - Divisão (/)")
        print("5 - Sair")

        opcao = input("Digite a opção desejada: ").strip()

        if opcao == "1":
            resultado = numero1 + numero2
            print(f"Resultado: {numero1} + {numero2} = {resultado}")
        elif opcao == "2":
            resultado = numero1 - numero2
            print(f"Resultado: {numero1} - {numero2} = {resultado}")
        elif opcao == "3":
            resultado = numero1 * numero2
            print(f"Resultado: {numero1} * {numero2} = {resultado}")
        elif opcao == "4":
            if numero2 == 0:
                print("Não é possível dividir por zero.")
            else:
                resultado = numero1 / numero2
                print(f"Resultado: {numero1} / {numero2} = {resultado}")
        elif opcao == "5":
            print("Calculadora encerrada. Até mais!")
            break
        else:
            print("Opção inválida. Escolha uma opção de 1 a 5.")

        print()

if __name__ == "__main__":
    calculadora()
