# Projeto 1 — Calculadora em Python

## Descrição
Este projeto é uma calculadora simples feita em Python. Ela recebe dois números digitados pelo usuário e permite realizar adição, subtração, multiplicação e divisão.

## Arquivos
- `calculator.py`: código-fonte da calculadora.
- `executar.sh`: script para iniciar o programa em sistemas Linux/macOS com Python 3 instalado.
- `README.md`: documentação do projeto.

## Requisitos
- Python 3 instalado.
- Para usar o script `.sh`, um terminal compatível com Bash.

## Como executar o arquivo `.sh`
1. Baixe ou clone este repositório.
2. Abra o terminal na pasta do projeto.
3. Dê permissão de execução ao script:
   ```bash
   chmod +x executar.sh
   ```
4. Execute:
   ```bash
   ./executar.sh
   ```

Se o comando `python3` não funcionar no seu sistema, execute o arquivo diretamente com:
```bash
python3 calculator.py
```

## Como o código Python funciona
1. A função `calculadora()` exibe o título do programa.
2. O laço `while True` permite fazer operações consecutivas até que o usuário escolha sair.
3. O programa usa `input()` para receber dois números e `float()` para convertê-los em números decimais. A troca de vírgula por ponto facilita digitar números no formato brasileiro.
4. Uma sequência de condições `if`/`elif` identifica a operação escolhida.
5. O código calcula adição, subtração, multiplicação ou divisão e usa `print()` para mostrar o resultado.
6. Antes da divisão, o programa verifica se o segundo número é zero, evitando uma divisão inválida.
7. Se a entrada numérica não for válida, `try`/`except` mostra uma mensagem e solicita os dados novamente.
8. A opção 5 encerra o laço e finaliza a calculadora.

## Observação
Este projeto é uma versão de exemplo baseada nos requisitos mostrados na atividade. Confira se corresponde ao código que você desenvolveu nas aulas antes de enviar a entrega.
